// server.js - Node.js Express Backend

const express = require('express');
const multer = require('multer'); // For handling file uploads
const { Pool } = require('pg'); // PostgreSQL client
const XLSX = require('xlsx'); // For parsing Excel files
const cors = require('cors'); // For Cross-Origin Resource Sharing
const dotenv = require('dotenv'); // For loading environment variables
const path = require('path'); // Node.js path module for file paths

// Load environment variables from .env file
dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000; // Use port 5000, or environment variable

// Enable CORS for all origins (for development)
// In production, you would restrict this to your frontend's domain:
// app.use(cors({ origin: 'http://localhost:4200' }));
app.use(cors());

// --- Database Configuration ---
const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) {
    console.error('DATABASE_URL is not set in .env file. Exiting.');
    process.exit(1);
}

const pool = new Pool({
    connectionString: DATABASE_URL,
});

// Test database connection
pool.connect()
    .then(client => {
        console.log('Successfully connected to PostgreSQL database!');
        client.release(); // Release the client back to the pool
    })
    .catch(err => {
        console.error('Error connecting to database:', err.message);
        console.error('Please check your DATABASE_URL in .env:', DATABASE_URL);
        process.exit(1); // Exit if database connection fails
    });

// --- Multer Storage Configuration ---
// Configure multer for in-memory storage (file won't be saved to disk)
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// Helper function to sanitize column names for PostgreSQL
function sanitizeColumnName(colName) {
    // Convert to lowercase, replace spaces/special chars with underscores, remove parentheses/dots
    return colName.toLowerCase().replace(/[\s\.\-\(\)\/]/g, '_');
}

// --- API Endpoints ---

// Endpoint for uploading Excel files
app.post('/upload', upload.single('file'), async (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded.' });
    }

    const fileExtension = path.extname(req.file.originalname).toLowerCase();
    if (fileExtension !== '.xlsx' && fileExtension !== '.xls') {
        return res.status(400).json({ error: 'Invalid file type. Only .xlsx and .xls are allowed.' });
    }

    try {
        // Read Excel file from buffer
        const workbook = XLSX.read(req.file.buffer, { type: 'buffer', cellDates: true });
        const sheetName = workbook.SheetNames[0]; // Get the first sheet
        const worksheet = workbook.Sheets[sheetName];

        // Convert sheet to JSON array (array of objects)
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

        if (jsonData.length === 0) {
            return res.status(200).json({ message: 'The uploaded Excel file is empty or has no data rows.' });
        }

        // The first row is assumed to be headers
        const originalHeaders = jsonData[0];
        const dataRows = jsonData.slice(1); // Actual data starts from the second row

        if (dataRows.length === 0) {
            return res.status(200).json({ message: 'The uploaded Excel file has headers but no data rows.' });
        }

        // Sanitize headers for PostgreSQL column names
        const sanitizedHeaders = originalHeaders.map(header => sanitizeColumnName(header));

        // Generate a dynamic table name from the filename
        const baseFilename = path.parse(req.file.originalname).name;
        const tableNameSuffix = baseFilename.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
        let tableName = `excel_data_${tableNameSuffix || 'default'}`; // 'default' if suffix is empty
        tableName = tableName.substring(0, 63); // PostgreSQL identifier max length

        // Construct CREATE TABLE SQL
        const columnsSql = sanitizedHeaders.map(header => `"${header}" TEXT`).join(', '); // All columns as TEXT for flexibility
        const createTableSql = `DROP TABLE IF EXISTS "${tableName}"; CREATE TABLE "${tableName}" (${columnsSql});`;

        // Construct INSERT SQL
        const placeholders = originalHeaders.map((_, i) => `$${i + 1}`).join(', ');
        const insertSql = `INSERT INTO "${tableName}" ("${sanitizedHeaders.join('", "')}") VALUES (${placeholders});`;

        const client = await pool.connect();
        try {
            await client.query('BEGIN'); // Start transaction

            // Create/Replace table
            await client.query(createTableSql);

            // Insert data rows
            for (const row of dataRows) {
                // Ensure row has enough elements for all headers, pad with null if not
                const values = originalHeaders.map((_, i) => {
                    let val = row[i];
                    // Convert Date objects to ISO string for PostgreSQL
                    if (val instanceof Date) {
                        return val.toISOString();
                    }
                    return val !== undefined ? String(val) : null; // Convert all to string or null
                });
                await client.query(insertSql, values);
            }

            await client.query('COMMIT'); // Commit transaction

            res.status(200).json({
                message: `Excel data successfully uploaded to table '${tableName}'.`,
                table_name: tableName,
                columns: sanitizedHeaders // Send back sanitized columns
            });

        } catch (dbErr) {
            await client.query('ROLLBACK'); // Rollback on error
            console.error('Database transaction failed:', dbErr);
            res.status(500).json({ error: `Failed to store data in database: ${dbErr.message}` });
        } finally {
            client.release(); // Always release client
        }

    } catch (excelErr) {
        console.error('Error processing Excel file:', excelErr);
        res.status(500).json({ error: `Failed to process Excel file: ${excelErr.message}` });
    }
});

// Endpoint for searching data
app.get('/search', async (req, res) => {
    const { table, query, column } = req.query;

    if (!table) {
        return res.status(400).json({ error: 'Table name is required for searching.' });
    }
    if (!query) {
        return res.status(400).json({ error: 'Search query cannot be empty.' });
    }

    const client = await pool.connect();
    try {
        // Verify table existence and get columns
        const tableExistsResult = await client.query(`
            SELECT EXISTS (
                SELECT 1
                FROM information_schema.tables
                WHERE table_schema = 'public' AND table_name = $1
            );
        `, [table]);

        if (!tableExistsResult.rows[0].exists) {
            return res.status(404).json({ error: `Table '${table}' does not exist. Please upload data first or select a valid table.` });
        }

        const columnsResult = await client.query(`
            SELECT column_name FROM information_schema.columns
            WHERE table_schema = 'public' AND table_name = $1;
        `, [table]);
        const dbSanitizedColumns = columnsResult.rows.map(row => row.column_name);

        if (dbSanitizedColumns.length === 0) {
            return res.status(200).json({ message: `Table '${table}' has no columns. It might be empty or malformed.` });
        }

        let whereClauses = [];
        const queryParamIndex = 1; // For parameterized query

        if (column) {
            const sanitizedColumn = sanitizeColumnName(column);
            if (dbSanitizedColumns.includes(sanitizedColumn)) {
                whereClauses.push(`CAST("${sanitizedColumn}" AS TEXT) ILIKE $${queryParamIndex}`);
            } else {
                return res.status(400).json({ error: `Column '${column}' (sanitized to '${sanitizedColumn}') does not exist in table '${table}'.` });
            }
        } else {
            // Search across all columns
            for (const col of dbSanitizedColumns) {
                whereClauses.push(`CAST("${col}" AS TEXT) ILIKE $${queryParamIndex}`);
            }
        }

        if (whereClauses.length === 0) {
            return res.status(200).json({ message: 'No searchable columns found in the table schema.' });
        }

        const whereClauseStr = whereClauses.join(' OR ');
        const selectSql = `SELECT * FROM "${table}" WHERE ${whereClauseStr};`;

        const searchResult = await client.query(selectSql, [`%${query}%`]);

        res.status(200).json({
            headers: dbSanitizedColumns, // Send back sanitized headers
            rows: searchResult.rows
        });

    } catch (err) {
        console.error('Error during search:', err);
        res.status(500).json({ error: `Failed to perform search: ${err.message}` });
    } finally {
        client.release();
    }
});

// Endpoint to get list of uploaded tables
app.get('/tables', async (req, res) => {
    const client = await pool.connect();
    try {
        const result = await client.query(`
            SELECT tablename
            FROM pg_tables
            WHERE schemaname = 'public' AND tablename LIKE 'excel_data_%';
        `);
        const tableNames = result.rows.map(row => row.tablename);
        res.status(200).json({ tables: tableNames });
    } catch (err) {
        console.error('Error getting table list:', err);
        res.status(500).json({ error: `Failed to retrieve table list: ${err.message}` });
    } finally {
        client.release();
    }
});

// Start the server
app.listen(PORT, () => {
    console.log(`Node.js backend server running on http://localhost:${PORT}`);
});
